library(testthat)
library(tensorICA)

test_check("tensorICA")
