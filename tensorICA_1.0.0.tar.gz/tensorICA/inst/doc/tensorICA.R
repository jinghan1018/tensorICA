### R code from vignette source 'tensorICA.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: install1
###################################################
library(tensorICA);
data(buccalbloodtensor);


###################################################
### code chunk number 2: check1
###################################################
require(isva);
Dim.l <- EstDim(buccalbloodtensor$data);
dim <- Dim.l$dim;
dJ <- Dim.l$dJ;


###################################################
### code chunk number 3: check2
###################################################
tica.o <- DoTICA(Data = buccalbloodtensor$data, dim = dim, method = "FOBI");


###################################################
### code chunk number 4: check3
###################################################
phenotype.p <- cor_phenotype(tica.o = tica.o, phenotype = buccalbloodtensor$pheno.l,
                              phenotype.is.categorical = buccalbloodtensor$pheno.i);
phenotype.p$pv.p;


###################################################
### code chunk number 5: a1
###################################################
phenotype.p12 <- cor_phenotype(tica.o = tica.o, phenotype = buccalbloodtensor$pheno.l, 
                                phenotype.is.categorical = buccalbloodtensor$pheno.i,
                                component = 12);
phenotype.p12$compheno.pl$SmokingStatus;


###################################################
### code chunk number 6: a10
###################################################
require(dplyr)
require(tidyr)
require(ggplot2)
phenotype = buccalbloodtensor$pheno.l;
phenotype.is.categorical = buccalbloodtensor$pheno.i;
component = 12;
A_star.m <- t(solve(tica.o$TICA.W[[2]]))%*%t(tica.o$TPCA.U[[2]]);
tmp.df <- data.frame(x = as.factor(buccalbloodtensor$pheno.l$SmokingStatus), y = A_star.m[component,])
tmp.df <- na.omit(tmp.df)
sample_size <- tmp.df %>% group_by(x) %>% summarise(n())
ggplot(tmp.df, aes(x = x, y = y, fill = x)) + geom_boxplot(width = 0.5) +
  scale_fill_brewer(type = "div", palette = 5, aesthetics = "fill", name = "Sample Size",          labels = paste0("n = ", sample_size$`n()`)) +
  theme_bw() + theme(text = element_text(size = 14)) + 
  labs(x = "SmokingStatus", y = "Weight", title=paste0("Component ",component))


###################################################
### code chunk number 7: a11
###################################################
phenotype.p12$compheno.pl$SmokingPackYear


###################################################
### code chunk number 8: a4
###################################################
require(cowplot)
require(ggplot2)
tp <- seq(501,562)
nt.idx <- c(1,2)
component <- 12
x <- tica.o$TICA.S[nt.idx[1],component,]
y <- tica.o$TICA.S[nt.idx[2],component,]
col.idx <- rep(1,dim(tica.o$TICA.S)[3])
col.idx[tp] <- 2
tmp.df <- data.frame(x = x, y = y, color = as.factor(col.idx))
tmp.p <- ggplot(tmp.df,aes(x = x, y = y,  colour = color)) + geom_point(pch = 20, size = 3) + 
  scale_color_manual(values = c("black","red"), name="", labels=c("Nonsmoking CpG","Smoking CpG")) +
  theme_bw() + theme(axis.text=element_text(size=14), axis.title=element_text(size=14), legend.text = element_text(size = 14),legend.position="top")
legend.p <- get_legend(tmp.p)
weight.p <- ggplot(tmp.df,aes(x = x, y = y,  colour = color)) + geom_point(pch = 20, size = 3) + 
  scale_color_manual(values = c("black","red"), name="", guide = FALSE)  +
  theme_bw() + theme(axis.text=element_text(size=14), axis.title=element_text(size=14),legend.text = element_text(size = 14)) + 
  labs(x = paste0("S[",nt.idx[1],",",component,",*]"), y = paste0("S[",nt.idx[2],",",component,",*]"), title="")
abs.p <- ggplot(tmp.df,aes(x = abs(x), y = abs(y),  colour = color)) + geom_point(pch = 20, size = 3) + 
  scale_color_manual(values = c("black","red"), name="", guide = FALSE)  +
  theme_bw() + theme(axis.text=element_text(size=14), axis.title=element_text(size=14), legend.text = element_text(size = 14)) + 
  labs(x = paste0("|S[",nt.idx[1],",",component,",*]|"), y = paste0("|S[",nt.idx[2],",",component,",*]|"), title="")

box_abs1.p <- ggplot(tmp.df, aes(x = color, y = abs(x), fill = color, colour = color)) + geom_boxplot(width = 0.5) + 
  scale_color_manual(values = c("black","red"), guide = FALSE) + scale_fill_manual(values = c("grey","pink"), guide = FALSE) +
  scale_x_discrete(labels = c("N","S")) +
  theme_bw() + theme(axis.text=element_text(size=10), axis.title=element_text(size=10), legend.text = element_text(size = 10),plot.title = element_text(colour = "red",size = 8)) + 
  labs(y = paste0("|S[",nt.idx[1],",",component,",*]|"), x = "", title=paste0("P = ", format(wilcox.test(abs(filter(tmp.df,color == 2)$x), abs(filter(tmp.df,color == 1)$x), alternative = "g")$p.value, digits = 3)))
box_abs2.p <- ggplot(tmp.df, aes(x = color, y = abs(y), fill = color, colour = color)) + geom_boxplot(width = 0.5) + 
  scale_color_manual(values = c("black","red"), guide = FALSE) + scale_fill_manual(values = c("grey","pink"), guide = FALSE) +
  scale_x_discrete(labels = c("N","S")) +
  theme_bw() + theme(axis.text=element_text(size=10), axis.title=element_text(size=10), legend.text = element_text(size = 10),plot.title = element_text(colour = "red",size = 8)) + 
  labs(y = paste0("|S[",nt.idx[2],",",component,",*]|"), x = "", title=paste0("P = ", format(wilcox.test(abs(filter(tmp.df,color == 2)$y), abs(filter(tmp.df,color == 1)$y), alternative = "g")$p.value, digits = 3)))
box_abs_p <- plot_grid(box_abs1.p, box_abs2.p, nrow = 2)
weight_abs.p <- plot_grid(abs.p, box_abs_p, ncol = 2, rel_widths =c(2,1))

x_p <- tica.o$TICA.projS[[nt.idx[1]]][component,]
y_p <- tica.o$TICA.projS[[nt.idx[2]]][component,]
tmp.df <- data.frame(x = x_p, y = y_p, color = as.factor(col.idx))
weight_prime.p <- ggplot(tmp.df,aes(x = x, y = y,  colour = color)) + geom_point(pch = 20, size = 3) + 
  scale_color_manual(values = c("black","red"), name="", guide = FALSE)  +
  theme_bw() + theme(axis.text=element_text(size=14), axis.title=element_text(size=14),legend.text = element_text(size = 14)) + 
  labs(x = paste0("S'[",nt.idx[1],",",component,",*]"), y = paste0("S'[",nt.idx[2],",",component,",*]"), title="")
abs_prime.p <- ggplot(tmp.df,aes(x = abs(x), y = abs(y),  colour = color)) + geom_point(pch = 20, size = 3) + 
  scale_color_manual(values = c("black","red"), name="", guide = FALSE)  +
  theme_bw() + theme(axis.text=element_text(size=14), axis.title=element_text(size=14), legend.text = element_text(size = 14)) + 
  labs(x = paste0("|S'[",nt.idx[1],",",component,",*]|"), y = paste0("|S'[",nt.idx[2],",",component,",*]|"), title="")
box_abs1_prime.p <- ggplot(tmp.df, aes(x = color, y = abs(x), fill = color, colour = color)) + geom_boxplot(width = 0.5) + 
  scale_color_manual(values = c("black","red"), guide = FALSE) + scale_fill_manual(values = c("grey","pink"), guide = FALSE) +
  scale_x_discrete(labels = c("N","S")) +
  theme_bw() + theme(axis.text = element_text(size=10), axis.title = element_text(size=10), legend.text = element_text(size = 10),plot.title = element_text(colour = "red",size = 8)) + 
  labs(y = paste0("|S'[",nt.idx[1],",",component,",*]|"), x = "", title=paste0("P = ", format(wilcox.test(abs(filter(tmp.df,color == 2)$x), abs(filter(tmp.df,color == 1)$x), alternative = "g")$p.value, digits = 3)))
box_abs2_prime.p <- ggplot(tmp.df, aes(x = color, y = abs(y), fill = color, colour = color)) + geom_boxplot(width = 0.5) + 
  scale_color_manual(values = c("black","red"), guide = FALSE) + scale_fill_manual(values = c("grey","pink"), guide = FALSE) +
  scale_x_discrete(labels = c("N","S")) +
  theme_bw() + theme(axis.text = element_text(size=10), axis.title = element_text(size=10), legend.text = element_text(size = 10),plot.title = element_text(colour = "red",size = 8)) + 
  labs(y = paste0("|S'[",nt.idx[2],",",component,",*]|"), x = "", title=paste0("P = ", format(wilcox.test(abs(filter(tmp.df,color == 2)$y), abs(filter(tmp.df,color == 1)$y), alternative = "g")$p.value, digits = 3)))
box_abs_prime.p <- plot_grid(box_abs1_prime.p, box_abs2_prime.p, nrow = 2)
weight_prime_abs.p <- plot_grid(abs_prime.p, box_abs_prime.p, ncol = 2, rel_widths =c(2,1))
main.p <-  plot_grid(plotlist = list(weight.p = weight.p, weight_abs.p = weight_abs.p, weight_prime.p = weight_prime.p, weight_prime_abs.p = weight_prime_abs.p),nrow = 2,rel_widths = c(2,3))
plot_grid(main.p,legend.p,nrow = 2, rel_heights = c(1,0.05))


###################################################
### code chunk number 9: check6
###################################################
feature.k <- feature_selection(tica.o = tica.o, component = 12, CLkurt = 0.95);
buccalbloodtensor$testDMCs[feature.k$pred.idx[[1]]];
feature.k$k.p[[1]];


###################################################
### code chunk number 10: check8
###################################################
feature.n <- feature_selection(tica.o = tica.o, component = 12, topN = 62);
buccalbloodtensor$testDMCs[feature.n$pred.idx[[1]]];


###################################################
### code chunk number 11: d1
###################################################
(profile.p <- feature_profile(Data = buccalbloodtensor$data, 
phenotype.v = buccalbloodtensor$pheno.l$SmokingStatus, phenotype.is.categorical = TRUE,
feature.index = feature.k$pred.idx[[1]][seq_len(10)], tissue.index = 1));


###################################################
### code chunk number 12: d2
###################################################
(profile.p <- feature_profile(Data = buccalbloodtensor$data, 
phenotype.v = buccalbloodtensor$pheno.l$SmokingPackYear, phenotype.is.categorical = FALSE,
feature.index = feature.k$pred.idx[[1]][seq_len(10)], tissue.index = 1));


###################################################
### code chunk number 13: check7
###################################################
require(cowplot)
SE <- EstSE(tica.o = tica.o, tp = seq(501,562));
plot_grid(SE$se.p, SE$pv.p, nrow = 2);


###################################################
### code chunk number 14: sessionInfo
###################################################
toLatex(sessionInfo())


